/* ============================================================
   ToolKit — script.js
   Vanilla JS: auth (localStorage), free trial gating,
   dashboard (subscription + traffic view), modals, 4 tools
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  const TRIAL_DAYS = 60; // free access window after signup

  /* ---------------------------------------------------------
     Toast helper
  --------------------------------------------------------- */
  const toastEl = document.getElementById('toast');
  let toastTimer = null;
  function showToast(msg){
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
  }

  /* ---------------------------------------------------------
     Mobile nav burger
  --------------------------------------------------------- */
  const navBurger = document.getElementById('navBurger');
  const navLinks = document.getElementById('navLinks');
  navBurger.addEventListener('click', () => navLinks.classList.toggle('open'));
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));

  /* ---------------------------------------------------------
     Generic modal open/close
  --------------------------------------------------------- */
  function openModal(id){
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  function closeModal(id){
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = '';
  }
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape'){
      document.querySelectorAll('.modal-overlay.active').forEach(o => closeModal(o.id));
    }
  });

  /* ===========================================================
     AUTH + SUBSCRIPTION SYSTEM (localStorage based)
  =========================================================== */
  const USERS_KEY = 'toolkit_users';
  const SESSION_KEY = 'toolkit_session';

  function getUsers(){
    try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
    catch(e){ return []; }
  }
  function saveUsers(users){ localStorage.setItem(USERS_KEY, JSON.stringify(users)); }

  function getSession(){
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)) || null; }
    catch(e){ return null; }
  }
  function saveSession(session){ localStorage.setItem(SESSION_KEY, JSON.stringify(session)); }

  function daysLeftInTrial(user){
    const elapsedMs = Date.now() - user.trialStart;
    const elapsedDays = elapsedMs / (1000 * 60 * 60 * 24);
    return Math.ceil(TRIAL_DAYS - elapsedDays);
  }

  // true if the current user can open tools right now
  function hasToolAccess(){
    const session = getSession();
    if (!session) return false;
    if (session.plan === 'paid') return true;
    return daysLeftInTrial(session) > 0;
  }

  const authOverlay = document.getElementById('authOverlay');
  const authButtons = document.getElementById('authButtons');
  const userBox = document.getElementById('userBox');
  const welcomeText = document.getElementById('welcomeText');
  const planBadge = document.getElementById('planBadge');
  const authIntro = document.getElementById('authIntro');

  const loginBtn = document.getElementById('loginBtn');
  const signupBtn = document.getElementById('signupBtn');
  const logoutBtn = document.getElementById('logoutBtn');

  const authTabs = document.querySelectorAll('.auth-tab');
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');

  function switchAuthTab(tab){
    authTabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    loginForm.classList.toggle('active', tab === 'login');
    signupForm.classList.toggle('active', tab === 'signup');
    document.getElementById('loginError').textContent = '';
    document.getElementById('signupError').textContent = '';
  }
  authTabs.forEach(t => t.addEventListener('click', () => switchAuthTab(t.dataset.tab)));

  loginBtn.addEventListener('click', () => { authIntro.textContent = ''; switchAuthTab('login'); openModal('authOverlay'); });
  signupBtn.addEventListener('click', () => { authIntro.textContent = ''; switchAuthTab('signup'); openModal('authOverlay'); });

  function refreshNavUI(){
    const session = getSession();
    if (!session){
      authButtons.classList.remove('hidden');
      userBox.classList.add('hidden');
      return;
    }
    authButtons.classList.add('hidden');
    userBox.classList.remove('hidden');
    welcomeText.textContent = `Welcome, ${session.name}`;

    if (session.plan === 'paid'){
      planBadge.textContent = 'Pro';
      planBadge.className = 'plan-badge pro';
    } else {
      const left = daysLeftInTrial(session);
      if (left > 0){
        planBadge.textContent = `Trial: ${left}d left`;
        planBadge.className = 'plan-badge';
      } else {
        planBadge.textContent = 'Trial expired';
        planBadge.className = 'plan-badge expired';
      }
    }
  }
  refreshNavUI();

  // Sign up
  signupForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim().toLowerCase();
    const password = document.getElementById('signupPassword').value;
    const confirm = document.getElementById('signupConfirm').value;
    const errorEl = document.getElementById('signupError');

    if (password.length < 6){
      errorEl.textContent = 'Password must be at least 6 characters.';
      return;
    }
    if (password !== confirm){
      errorEl.textContent = 'Passwords do not match.';
      return;
    }
    const users = getUsers();
    if (users.some(u => u.email === email)){
      errorEl.textContent = 'An account with this email already exists.';
      return;
    }
    const trialStart = Date.now();
    users.push({ name, email, password, trialStart, plan: 'trial' });
    saveUsers(users);
    saveSession({ name, email, trialStart, plan: 'trial' });
    refreshNavUI();
    closeModal('authOverlay');
    signupForm.reset();
    errorEl.textContent = '';
    showToast(`Account created — your free month starts now, ${name}!`);
  });

  // Login
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');

    const users = getUsers();
    const match = users.find(u => u.email === email && u.password === password);
    if (!match){
      errorEl.textContent = 'Incorrect email or password.';
      return;
    }
    saveSession({ name: match.name, email: match.email, trialStart: match.trialStart, plan: match.plan });
    refreshNavUI();
    closeModal('authOverlay');
    loginForm.reset();
    errorEl.textContent = '';
    showToast(`Welcome back, ${match.name}!`);
  });

  // Logout
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem(SESSION_KEY);
    refreshNavUI();
    showToast('Logged out.');
  });

  /* ===========================================================
     TRAFFIC TRACKING (simple client-side analytics)
  =========================================================== */
  const TRAFFIC_KEY = 'toolkit_traffic';
  const TOOL_NAMES = { cv: 'CV Builder', qr: 'QR Generator', password: 'Password Generator', countdown: 'Countdown Timer' };

  function getTraffic(){
    try {
      const t = JSON.parse(localStorage.getItem(TRAFFIC_KEY));
      if (t && typeof t.visits === 'number' && t.tools) return t;
    } catch(e){}
    return { visits: 0, tools: { cv: 0, qr: 0, password: 0, countdown: 0 } };
  }
  function saveTraffic(t){ localStorage.setItem(TRAFFIC_KEY, JSON.stringify(t)); }

  // count this page load as a visit
  const traffic = getTraffic();
  traffic.visits += 1;
  saveTraffic(traffic);

  function logToolOpen(tool){
    const t = getTraffic();
    t.tools[tool] = (t.tools[tool] || 0) + 1;
    saveTraffic(t);
  }

  /* ===========================================================
     DASHBOARD — subscription view + traffic
  =========================================================== */
  const dashPlanBadge = document.getElementById('dashPlanBadge');
  const dashPlanDetail = document.getElementById('dashPlanDetail');
  const dashMemberSince = document.getElementById('dashMemberSince');
  const dashVisits = document.getElementById('dashVisits');
  const dashToolOpens = document.getElementById('dashToolOpens');
  const dashToolList = document.getElementById('dashToolList');

  function openDashboard(){
    const session = getSession();
    if (!session) return;

    if (session.plan === 'paid'){
      dashPlanBadge.textContent = 'Pro';
      dashPlanBadge.className = 'plan-badge pro';
      dashPlanDetail.textContent = 'Full access to all tools';
    } else {
      const left = daysLeftInTrial(session);
      dashPlanBadge.textContent = left > 0 ? 'Trial' : 'Trial expired';
      dashPlanBadge.className = 'plan-badge' + (left > 0 ? '' : ' expired');
      dashPlanDetail.textContent = left > 0 ? `${left} day(s) left in your free trial` : 'Your free trial has ended';
    }
    dashMemberSince.textContent = 'Member since ' + new Date(session.trialStart).toLocaleDateString();

    const t = getTraffic();
    dashVisits.textContent = t.visits;
    const totalOpens = Object.values(t.tools).reduce((a, b) => a + b, 0);
    dashToolOpens.textContent = totalOpens;

    dashToolList.innerHTML = '';
    Object.entries(TOOL_NAMES).forEach(([key, label]) => {
      const li = document.createElement('li');
      li.innerHTML = `<span>${label}</span><span>${t.tools[key] || 0} opens</span>`;
      dashToolList.appendChild(li);
    });

    openModal('dashboardOverlay');
  }

  document.getElementById('dashboardBtn').addEventListener('click', openDashboard);

  /* ===========================================================
     Tool card -> gate on login + trial, then open
  =========================================================== */
  const toolModalMap = { cv: 'cvOverlay', qr: 'qrOverlay', password: 'passwordOverlay', countdown: 'countdownOverlay' };

  document.querySelectorAll('.open-tool').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const tool = el.dataset.tool;
      const session = getSession();

      if (!session){
        authIntro.textContent = 'Please login or sign up to use this tool.';
        switchAuthTab('login');
        openModal('authOverlay');
        return;
      }
      if (!hasToolAccess()){
        showToast('Your free trial has ended.');
        openDashboard();
        return;
      }
      if (toolModalMap[tool]){
        logToolOpen(tool);
        openModal(toolModalMap[tool]);
      }
    });
  });

  /* ===========================================================
     TOOL — PASSWORD GENERATOR
  =========================================================== */
  const CHARS = {
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    lower: 'abcdefghijklmnopqrstuvwxyz',
    numbers: '0123456789',
    symbols: '!@#$%^&*()-_=+[]{}'
  };

  function generatePassword(length, opts){
    let pool = '';
    if (opts.upper) pool += CHARS.upper;
    if (opts.lower) pool += CHARS.lower;
    if (opts.numbers) pool += CHARS.numbers;
    if (opts.symbols) pool += CHARS.symbols;
    if (!pool) pool = CHARS.lower;

    let pwd = '';
    const array = new Uint32Array(length);
    crypto.getRandomValues(array);
    for (let i = 0; i < length; i++){
      pwd += pool[array[i] % pool.length];
    }
    return pwd;
  }

  function copyToClipboard(text){
    if (!text || text.includes('•')) { showToast('Generate a password first.'); return; }
    navigator.clipboard.writeText(text).then(() => showToast('Copied to clipboard!'))
      .catch(() => showToast('Could not copy — select manually.'));
  }

  const pwLength = document.getElementById('pwLength');
  const pwLengthVal = document.getElementById('pwLengthVal');
  const pwOutput = document.getElementById('pwOutput');
  const pwUpper = document.getElementById('pwUpper');
  const pwLower = document.getElementById('pwLower');
  const pwNumbers = document.getElementById('pwNumbers');
  const pwSymbols = document.getElementById('pwSymbols');
  const pwGenerateBtn = document.getElementById('pwGenerateBtn');
  const pwCopyBtn = document.getElementById('pwCopyBtn');
  const pwStrengthBar = document.querySelector('#pwStrength span');
  const pwStrengthLabel = document.getElementById('pwStrengthLabel');

  pwLength.addEventListener('input', () => pwLengthVal.textContent = pwLength.value);

  function updateStrength(length, opts){
    const variety = [opts.upper, opts.lower, opts.numbers, opts.symbols].filter(Boolean).length;
    let score = Math.min(100, (length / 40) * 60 + variety * 10);
    let label = 'weak', color = 'var(--danger)';
    if (score > 75){ label = 'strong'; color = 'var(--success)'; }
    else if (score > 45){ label = 'medium'; color = '#e0a52c'; }
    pwStrengthBar.style.width = score + '%';
    pwStrengthBar.style.background = color;
    pwStrengthLabel.textContent = `strength — ${label}`;
  }

  pwGenerateBtn.addEventListener('click', () => {
    const opts = { upper: pwUpper.checked, lower: pwLower.checked, numbers: pwNumbers.checked, symbols: pwSymbols.checked };
    if (!opts.upper && !opts.lower && !opts.numbers && !opts.symbols){
      showToast('Select at least one character type.');
      return;
    }
    const length = parseInt(pwLength.value, 10);
    const pwd = generatePassword(length, opts);
    pwOutput.textContent = pwd;
    updateStrength(length, opts);
  });
  pwCopyBtn.addEventListener('click', () => copyToClipboard(pwOutput.textContent));

  /* ===========================================================
     TOOL — CV BUILDER
  =========================================================== */
  const cvFields = ['cvName','cvEmail','cvPhone','cvAddress','cvSummary','cvEducation','cvExperience','cvSkills'];
  const cvPreviewMap = {
    cvSummary: 'pSummary',
    cvEducation: 'pEducation',
    cvExperience: 'pExperience',
    cvSkills: 'pSkills'
  };

  function updateCvPreview(){
    const name = document.getElementById('cvName').value.trim() || 'Your Name';
    const email = document.getElementById('cvEmail').value.trim();
    const phone = document.getElementById('cvPhone').value.trim();
    const address = document.getElementById('cvAddress').value.trim();

    document.getElementById('pName').textContent = name;
    document.getElementById('pContact').textContent = [email, phone, address].filter(Boolean).join(' · ') || 'email · phone · address';

    Object.entries(cvPreviewMap).forEach(([inputId, previewId]) => {
      const val = document.getElementById(inputId).value.trim();
      document.getElementById(previewId).textContent = val || '—';
    });
  }
  cvFields.forEach(id => document.getElementById(id).addEventListener('input', updateCvPreview));

  document.getElementById('cvDownloadBtn').addEventListener('click', () => {
    updateCvPreview();
    const docHtml = document.getElementById('cvDoc').innerHTML;
    const win = window.open('', '_blank');
    win.document.write(`
      <!DOCTYPE html><html><head><title>CV</title>
      <style>
        body{ font-family: Arial, sans-serif; color:#222; max-width:700px; margin:40px auto; padding:0 20px; }
        h2{ margin-bottom:.1em; } h4{ font-size:0.78rem; letter-spacing:.05em; text-transform:uppercase; color:#2b6fef; margin-bottom:.3em; }
        p{ white-space:pre-line; color:#333; }
        .cv-contact{ color:#666; font-size:0.85rem; margin-bottom:1.4em; }
        .cv-section{ margin-bottom:1.2em; }
      </style></head><body>${docHtml}</body></html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 300);
  });

  /* ===========================================================
     TOOL — QR GENERATOR
  =========================================================== */
  const qrInput = document.getElementById('qrInput');
  const qrOutput = document.getElementById('qrOutput');
  const qrDownloadBtn = document.getElementById('qrDownloadBtn');

  document.getElementById('qrGenerateBtn').addEventListener('click', () => {
    const value = qrInput.value.trim();
    if (!value){ showToast('Enter some text or a URL first.'); return; }
    qrOutput.innerHTML = '';
    new QRCode(qrOutput, {
      text: value,
      width: 200,
      height: 200,
      colorDark: '#111111',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
    });
    qrDownloadBtn.classList.remove('hidden');
  });

  qrDownloadBtn.addEventListener('click', () => {
    const img = qrOutput.querySelector('img');
    const canvas = qrOutput.querySelector('canvas');
    const src = img ? img.src : (canvas ? canvas.toDataURL('image/png') : null);
    if (!src){ showToast('Generate a QR code first.'); return; }
    const a = document.createElement('a');
    a.href = src;
    a.download = 'toolkit-qr-code.png';
    a.click();
  });

  /* ===========================================================
     TOOL — COUNTDOWN TIMER
  =========================================================== */
  const cdTarget = document.getElementById('cdTarget');
  const cdDays = document.getElementById('cdDays');
  const cdHours = document.getElementById('cdHours');
  const cdMinutes = document.getElementById('cdMinutes');
  const cdSeconds = document.getElementById('cdSeconds');
  const cdMessage = document.getElementById('cdMessage');
  let cdInterval = null;

  function pad(n){ return String(n).padStart(2, '0'); }

  function tickCountdown(targetTime){
    const now = new Date().getTime();
    const diff = targetTime - now;

    if (diff <= 0){
      clearInterval(cdInterval);
      cdDays.textContent = cdHours.textContent = cdMinutes.textContent = cdSeconds.textContent = '00';
      cdMessage.textContent = "time's up!";
      return;
    }
    const days = Math.floor(diff / (1000*60*60*24));
    const hours = Math.floor((diff % (1000*60*60*24)) / (1000*60*60));
    const minutes = Math.floor((diff % (1000*60*60)) / (1000*60));
    const seconds = Math.floor((diff % (1000*60)) / 1000);

    cdDays.textContent = pad(days);
    cdHours.textContent = pad(hours);
    cdMinutes.textContent = pad(minutes);
    cdSeconds.textContent = pad(seconds);
    cdMessage.textContent = 'counting down…';
  }

  document.getElementById('cdStartBtn').addEventListener('click', () => {
    if (!cdTarget.value){ showToast('Pick a target date and time.'); return; }
    const targetTime = new Date(cdTarget.value).getTime();
    if (isNaN(targetTime) || targetTime <= Date.now()){
      showToast('Please choose a time in the future.');
      return;
    }
    clearInterval(cdInterval);
    tickCountdown(targetTime);
    cdInterval = setInterval(() => tickCountdown(targetTime), 1000);
  });

});
